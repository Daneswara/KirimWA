<?php

if(isset($_GET["pesan"]) && isset($_GET["tujuan"])){
$pesan = $_GET["pesan"];
$tujuan = $_GET["tujuan"];
$isipesan = array(
  'tujuan' => $tujuan,
  'message' => $pesan
);
$data = array(
  'to' =>'/topics/news',
  'data' => $isipesan
);
echo json_encode($data);
$options = array(
  'http' => array(
    'method'  => 'POST',
    'content' => json_encode($data),
    'header' =>  "Authorization: key=AIzaSyAY-QQEOwvAuDKrE7-fSzJc-ELf6j-L-dw\r\n".
			"Content-Type: application/json\r\n" 
				
    )
);

$context  = stream_context_create($options);
$result = file_get_contents("https://fcm.googleapis.com/fcm/send", false, $context);
$response = json_decode($result);
//echo $context;
echo $result;
//echo $response;
}
?>